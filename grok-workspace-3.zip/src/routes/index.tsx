import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Clapperboard, RefreshCw, RotateCcw, Star, Wallet } from "lucide-react";
import {
  EVENTS_BEFORE_RELEASE,
  formatDelta,
  formatNum,
  freshGame,
  loadGame,
  nextSeason,
  openingGame,
  releaseFilm,
  rerollOffers,
  resolveChoice,
  saveGame,
  selectOffer,
  startShoot,
  type GameState,
  type Offer,
  type Outcome,
  type ReleaseResult,
} from "@/lib/tycoon";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [game, setGame] = useState<GameState>(() => openingGame());

  useEffect(() => {
    const saved = loadGame();
    if (saved) setGame(saved);
  }, []);

  useEffect(() => {
    if (!game.incident) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [game.incident]);

  function commit(next: GameState) {
    saveGame(next);
    setGame(next);
  }

  return (
    <main className="min-h-screen bg-bg text-fg">
      <StatusBar money={game.money} reputation={game.reputation} />
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 py-6 pb-16">
        {game.phase === "pick" ? (
          <PickBoard
            offers={game.offers}
            money={game.money}
            onReroll={() => commit(rerollOffers(game))}
            onSelect={(id) => commit(selectOffer(game, id))}
          />
        ) : game.phase === "release" && game.release ? (
          <ReleaseBoard
            offer={game.offers.find((item) => item.id === game.selectedId) ?? null}
            money={game.money}
            reputation={game.reputation}
            spent={game.spent}
            release={game.release}
            onNext={() => commit(nextSeason(game))}
          />
        ) : (
          <CastGate
            offer={game.offers.find((item) => item.id === game.selectedId) ?? null}
            spent={game.spent}
            money={game.money}
            reputation={game.reputation}
            outcome={game.outcome}
            shooting={game.incident !== null}
            resolvedCount={game.resolvedCount}
            onRestart={() => commit(freshGame())}
            onShoot={() => commit(startShoot(game))}
            onRelease={() => commit(releaseFilm(game))}
          />
        )}
      </div>
      {game.incident ? (
        <IncidentDialog
          incident={game.incident}
          onChoose={(choiceId) => commit(resolveChoice(game, choiceId))}
        />
      ) : null}
    </main>
  );
}

function StatusBar({ money, reputation }: { money: number; reputation: number }) {
  return (
    <header className="sticky top-0 z-20 border-b border-line bg-bg">
      <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-surface text-gold">
          <Clapperboard aria-hidden="true" className="size-5" />
        </span>
        <div className="min-w-0">
          <p className="text-sm text-muted">導演兼製片</p>
          <h1 className="truncate font-display text-xl text-balance">短劇製作大亨</h1>
        </div>
      </div>
      <div className="mx-auto grid max-w-5xl grid-cols-2 border-t border-line">
        <div className="flex items-start gap-3 px-4 py-3">
          <Wallet aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-gold" />
          <div>
            <p className="text-sm text-muted">資金</p>
            <p className="font-semibold tabular-nums">{formatNum(money)} 元</p>
          </div>
        </div>
        <div className="flex items-start gap-3 border-l border-line px-4 py-3">
          <Star aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-gold" />
          <div className="min-w-0 flex-1">
            <p className="text-sm text-muted">公司口碑</p>
            <p className="font-semibold tabular-nums">{reputation}</p>
            <div
              className="mt-2 h-1.5 overflow-hidden rounded-full bg-surface-2"
              role="meter"
              aria-label="公司口碑"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={reputation}
            >
              <div className="h-full rounded-full bg-gold" style={{ width: `${reputation}%` }} />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

function PickBoard({
  offers,
  money,
  onReroll,
  onSelect,
}: {
  offers: Offer[];
  money: number;
  onReroll: () => void;
  onSelect: (id: string) => void;
}) {
  return (
    <section className="flex flex-col gap-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="max-w-xl">
          <p className="text-sm text-gold">第一階段 · 劇本挑選</p>
          <h2 className="mt-1 font-display text-2xl text-balance">本週可開拍的三組組合</h2>
          <p className="mt-2 text-pretty text-muted">
            每組都是題材加人物。選定後會立刻扣除製作費，並進入選角。
          </p>
        </div>
        <button
          type="button"
          onClick={onReroll}
          className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 font-medium transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          <RefreshCw aria-hidden="true" className="size-4" />
          換一批
        </button>
      </div>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {offers.map((offer) => (
          <ScriptCard
            key={offer.id}
            offer={offer}
            money={money}
            onSelect={() => onSelect(offer.id)}
          />
        ))}
      </div>
    </section>
  );
}

function ScriptCard({
  offer,
  money,
  onSelect,
}: {
  offer: Offer;
  money: number;
  onSelect: () => void;
}) {
  const affordable = offer.cost <= money;
  const remain = money - offer.cost;
  return (
    <article className="flex flex-col rounded-2xl bg-paper p-5 text-paper-ink">
      <div className="flex items-center justify-between gap-3">
        <p className="font-display text-lg">方案 {offer.letter}</p>
        <p className="text-sm text-paper-muted">{offer.heat}</p>
      </div>
      <h3 className="mt-4 font-display text-3xl text-balance">{offer.hook}</h3>
      <p className="mt-1 text-paper-muted">× {offer.lead}</p>
      <p className="mt-4 text-pretty text-sm leading-relaxed text-paper-muted">{offer.pitch}</p>
      <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-paper-soft pt-4">
        <div>
          <dt className="text-sm text-paper-muted">成本</dt>
          <dd className="mt-1 font-semibold tabular-nums">{formatNum(offer.cost)} 元</dd>
        </div>
        <div>
          <dt className="text-sm text-paper-muted">預估基礎流量</dt>
          <dd className="mt-1 font-semibold tabular-nums">{formatNum(offer.traffic)}</dd>
        </div>
      </dl>
      <p className="mt-3 text-sm text-paper-muted">
        {affordable ? `開拍後餘額 ${formatNum(remain)} 元` : `還差 ${formatNum(offer.cost - money)} 元`}
      </p>
      <button
        type="button"
        onClick={onSelect}
        disabled={!affordable}
        className="mt-4 inline-flex h-12 items-center justify-center rounded-xl bg-gold font-semibold text-gold-ink transition-transform duration-150 ease-out active:scale-[0.96] disabled:bg-paper-soft disabled:text-paper-muted"
      >
        {affordable ? "選定此劇本" : "資金不足"}
      </button>
    </article>
  );
}

function CastGate({
  offer,
  spent,
  money,
  reputation,
  outcome,
  shooting,
  resolvedCount,
  onRestart,
  onShoot,
  onRelease,
}: {
  offer: Offer | null;
  spent: number;
  money: number;
  reputation: number;
  outcome: Outcome | null;
  shooting: boolean;
  resolvedCount: number;
  onRestart: () => void;
  onShoot: () => void;
  onRelease: () => void;
}) {
  const ready = resolvedCount >= EVENTS_BEFORE_RELEASE;
  return (
    <section className="grid grid-cols-1 items-start gap-6 md:grid-cols-2">
      <div className="flex flex-col gap-4">
        <p className="text-sm text-gold">第二階段 · 開拍</p>
        <h2 className="font-display text-3xl text-balance">
          {ready ? "三個突發都處理完了" : "劇本已選定，可以開始拍攝"}
        </h2>
        <p className="max-w-md text-pretty text-muted">
          {ready
            ? "片場撐過三關。按下殺青，全網會用播放量和利潤告訴你這部劇值不值。"
            : `連拍 ${EVENTS_BEFORE_RELEASE} 個突發才能殺青。現在是第 ${resolvedCount + 1} 關。`}
        </p>
        <div className="flex flex-col gap-3 sm:flex-row">
          <button
            type="button"
            onClick={ready ? onRelease : onShoot}
            disabled={shooting}
            className="inline-flex h-12 items-center justify-center rounded-xl bg-gold px-4 font-semibold text-gold-ink transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50"
          >
            {ready ? "電影殺青，全網上映！" : resolvedCount > 0 ? "繼續拍攝" : "開始拍攝"}
          </button>
          <button
            type="button"
            onClick={onRestart}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 font-medium transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            <RotateCcw aria-hidden="true" className="size-4" />
            重新開季
          </button>
        </div>
        {outcome ? <OutcomeNote outcome={outcome} /> : null}
      </div>
      {offer ? (
        <article className="rounded-2xl bg-paper p-5 text-paper-ink">
          <p className="text-sm text-paper-muted">已鎖定 · 方案 {offer.letter}</p>
          <h3 className="mt-2 font-display text-3xl text-balance">
            {offer.hook}
            <span className="mt-1 block text-lg text-paper-muted">× {offer.lead}</span>
          </h3>
          <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-paper-soft pt-4">
            <div>
              <dt className="text-sm text-paper-muted">已扣製作費</dt>
              <dd className="mt-1 font-semibold tabular-nums">{formatNum(spent)} 元</dd>
            </div>
            <div>
              <dt className="text-sm text-paper-muted">預估基礎流量</dt>
              <dd className="mt-1 font-semibold tabular-nums">{formatNum(offer.traffic)}</dd>
            </div>
            <div>
              <dt className="text-sm text-paper-muted">剩餘資金</dt>
              <dd className="mt-1 font-semibold tabular-nums">{formatNum(money)} 元</dd>
            </div>
            <div>
              <dt className="text-sm text-paper-muted">口碑</dt>
              <dd className="mt-1 font-semibold tabular-nums">{reputation}</dd>
            </div>
          </dl>
          <p className="mt-4 text-sm text-paper-muted">突發進度 {Math.min(resolvedCount, EVENTS_BEFORE_RELEASE)} / {EVENTS_BEFORE_RELEASE}</p>
        </article>
      ) : null}
    </section>
  );
}

function ReleaseBoard({
  offer,
  money,
  reputation,
  spent,
  release,
  onNext,
}: {
  offer: Offer | null;
  money: number;
  reputation: number;
  spent: number;
  release: ReleaseResult;
  onNext: () => void;
}) {
  const loop = [...release.comments, ...release.comments];
  const profitLabel = release.profit >= 0 ? "本劇總利潤" : "本劇虧損";
  return (
    <section className="grid grid-cols-1 items-start gap-6 lg:grid-cols-2">
      <div className="flex flex-col gap-4">
        <p className="text-sm text-gold">第三階段 · 上映</p>
        <h2 className="font-display text-3xl text-balance">電影殺青，全網上映</h2>
        {offer ? (
          <p className="text-pretty text-muted">
            {offer.hook} × {offer.lead} 已經推上全網。播放量吃的是基礎流量、拍完剩的口碑，還有你口袋裡的資金。
          </p>
        ) : null}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <article className="rounded-2xl bg-paper p-4 text-paper-ink">
            <p className="text-sm text-paper-muted">全網最終播放量</p>
            <p className="mt-1 font-display text-3xl tabular-nums">{formatNum(release.views)}</p>
          </article>
          <article className="rounded-2xl bg-paper p-4 text-paper-ink">
            <p className="text-sm text-paper-muted">{profitLabel}</p>
            <p className="mt-1 font-display text-3xl tabular-nums">{formatNum(release.profit)} 元</p>
          </article>
        </div>
        <div className="rounded-2xl border border-line bg-surface p-4 text-sm">
          <p className="text-muted">
            播放量 = 基礎流量 {formatNum(release.baseTraffic)} × 口碑係數 {release.factorLabel}（口碑 {reputation} ÷ 50）+ 剩餘資金 {formatNum(money)}
          </p>
          <p className="mt-2 text-muted">
            總利潤 = 播放量 × 0.08 − 劇本製作費 {formatNum(spent)} 元
          </p>
        </div>
        <button
          type="button"
          onClick={onNext}
          className="inline-flex h-12 items-center justify-center self-start rounded-xl bg-gold px-4 font-semibold text-gold-ink transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          開啟下一賽季
        </button>
      </div>
      <aside className="flex h-96 flex-col overflow-hidden rounded-2xl border border-line bg-surface">
        <p className="shrink-0 border-b border-line px-4 py-3 text-sm text-gold">彈幕 · 網友毒舌評論</p>
        <div className="min-h-0 flex-1 overflow-hidden">
          <div className="comment-reel">
            {loop.map((line, index) => (
              <p key={`${line}-${index}`} className="border-b border-line px-4 py-3 text-sm">
                {line}
              </p>
            ))}
          </div>
        </div>
      </aside>
    </section>
  );
}

function OutcomeNote({ outcome }: { outcome: Outcome }) {
  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <p className="text-sm text-gold">{outcome.title}</p>
      <p className="mt-1 font-medium">{outcome.choiceLabel}</p>
      <p className="mt-2 text-pretty text-sm text-muted">{outcome.result}</p>
      <p className="mt-3 text-sm tabular-nums text-fg">
        資金 {formatDelta(outcome.moneyDelta)} 元 · 口碑 {formatDelta(outcome.reputationDelta)}
      </p>
    </div>
  );
}

function IncidentDialog({
  incident,
  onChoose,
}: {
  incident: GameState["incident"];
  onChoose: (choiceId: string) => void;
}) {
  if (!incident) return null;
  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-bg/80 p-4 sm:items-center">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="incident-title"
        className="w-full max-w-lg max-h-screen overflow-y-auto rounded-2xl bg-paper p-5 text-paper-ink"
      >
        <p className="text-sm text-paper-muted">拍攝突發事件</p>
        <h2 id="incident-title" className="mt-1 font-display text-2xl text-balance">
          {incident.title}
        </h2>
        <p className="mt-3 text-pretty text-sm leading-relaxed text-paper-muted">{incident.setup}</p>
        <div className="mt-5 flex flex-col gap-3">
          {incident.choices.map((choice) => (
            <button
              key={choice.id}
              type="button"
              onClick={() => onChoose(choice.id)}
              className="rounded-xl border border-paper-soft bg-paper-soft px-4 py-3 text-left transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              <span className="block font-semibold">{choice.label}</span>
              <span className="mt-1 block text-sm tabular-nums text-paper-muted">
                資金 {formatDelta(choice.money)} 元 · 口碑 {formatDelta(choice.reputation)}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
