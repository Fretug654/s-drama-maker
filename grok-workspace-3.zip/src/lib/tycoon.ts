export const START_MONEY = 100_000;
export const START_REPUTATION = 50;

export type Letter = "A" | "B" | "C";

export type Offer = {
  id: string;
  letter: Letter;
  hook: string;
  lead: string;
  pitch: string;
  cost: number;
  traffic: number;
  heat: string;
};

export type Phase = "pick" | "cast" | "release";

export type Choice = {
  id: string;
  label: string;
  money: number;
  reputation: number;
  result: string;
};

export type Incident = {
  id: string;
  title: string;
  setup: string;
  choices: Choice[];
};

export type Outcome = {
  incidentId: string;
  title: string;
  choiceLabel: string;
  result: string;
  moneyDelta: number;
  reputationDelta: number;
};

export type ReleaseResult = {
  views: number;
  profit: number;
  baseTraffic: number;
  factorLabel: string;
  comments: string[];
};

export const EVENTS_BEFORE_RELEASE = 3;

export type GameState = {
  version: 1;
  money: number;
  reputation: number;
  phase: Phase;
  offers: Offer[];
  selectedId: string | null;
  spent: number;
  incident: Incident | null;
  outcome: Outcome | null;
  resolvedCount: number;
  seenIds: string[];
  release: ReleaseResult | null;
};

const STORAGE_KEY = "duanju-tycoon-v1";

type Hook = { label: string; cost: number; traffic: number };
type Lead = { label: string; cost: number; traffic: number };

const HOOKS: Hook[] = [
  { label: "戰神歸來", cost: 28000, traffic: 420000 },
  { label: "手撕渣男", cost: 12000, traffic: 260000 },
  { label: "重生復仇", cost: 22000, traffic: 380000 },
  { label: "閃婚霸總", cost: 26000, traffic: 350000 },
  { label: "真假千金", cost: 18000, traffic: 310000 },
  { label: "追妻火葬場", cost: 20000, traffic: 400000 },
  { label: "帶球跑", cost: 14000, traffic: 240000 },
  { label: "隱婚馬甲", cost: 24000, traffic: 360000 },
  { label: "穿越宮鬥", cost: 36000, traffic: 450000 },
  { label: "神醫下山", cost: 20000, traffic: 280000 },
  { label: "系統逆襲", cost: 16000, traffic: 250000 },
  { label: "豪門棄婦", cost: 15000, traffic: 270000 },
  { label: "替嫁契約", cost: 17000, traffic: 290000 },
  { label: "鑑寶撿漏", cost: 11000, traffic: 180000 },
  { label: "直播打臉", cost: 13000, traffic: 330000 },
  { label: "先婚後愛", cost: 16000, traffic: 300000 },
  { label: "團寵奶包", cost: 19000, traffic: 340000 },
  { label: "年代逆襲", cost: 21000, traffic: 260000 },
];

const LEADS: Lead[] = [
  { label: "贅婿", cost: 8000, traffic: 1.15 },
  { label: "主婦", cost: 4000, traffic: 0.95 },
  { label: "千金", cost: 12000, traffic: 1.2 },
  { label: "霸總", cost: 14000, traffic: 1.18 },
  { label: "女強人", cost: 9000, traffic: 1.1 },
  { label: "龍王", cost: 10000, traffic: 1.12 },
  { label: "白月光", cost: 7000, traffic: 1.05 },
  { label: "病嬌", cost: 6000, traffic: 1.08 },
  { label: "婆媳", cost: 3000, traffic: 0.9 },
  { label: "農村少年", cost: 2000, traffic: 0.85 },
  { label: "王牌律師", cost: 11000, traffic: 1.06 },
  { label: "天才醫生", cost: 10000, traffic: 1.04 },
  { label: "落魄千金", cost: 8000, traffic: 1.1 },
  { label: "隱藏大佬", cost: 9000, traffic: 1.14 },
  { label: "單親媽媽", cost: 5000, traffic: 1 },
];

const LETTERS: Letter[] = ["A", "B", "C"];

const INCIDENTS: Incident[] = [
  {
    id: "tesla",
    title: "金主硬塞廣告",
    setup: "金主配偶要求在古裝劇裡硬塞一輛特斯拉當坐騎，還要主角對著車子發表兩分鐘讚美。",
    choices: [
      { id: "a", label: "順從金主", money: 20000, reputation: -15, result: "古裝主角當眾夸車。錢進帳了，彈幕已經在問這是哪個朝代的牌照。" },
      { id: "b", label: "嚴詞拒絕，文人要有骨氣", money: -10000, reputation: 20, result: "尾款黃了，但組裡有人第一次喊你導演，而不是金主的傳聲筒。" },
      { id: "c", label: "魔改成穿越來的神車", money: 5000, reputation: 5, result: "你讓霸總說這是未來坐騎。荒謬被收編成設定，居然還有人磕上了。" },
    ],
  },
  {
    id: "affair",
    title: "主演爆出驚天大瓜",
    setup: "男主角被狗仔爆出同時劈腿四個女網紅，熱搜直接炸開，距離今晚的條還有三小時。",
    choices: [
      { id: "a", label: "砸錢撤熱搜", money: -30000, reputation: -5, result: "熱搜下去了，帳單沒有。觀眾只記得你在遮，不記得你在拍什麼。" },
      { id: "b", label: "加一場他被扇巴掌的戲", money: -5000, reputation: 25, result: "你把瓜寫進正片。巴掌比聲明有用，全網說這才叫因果。" },
      { id: "c", label: "換角，找群演頂替", money: -20000, reputation: 10, result: "臉換了，戲還在。老粉罵一輪，新觀眾根本沒發現男主曾經有過新聞。" },
    ],
  },
  {
    id: "pan",
    title: "扇巴掌道具失誤",
    setup: "道具組把軟膠巴掌換成真皮厚平底鍋。女主角一掌下去，男主角輕微腦震盪，叫聲還在錄音裡。",
    choices: [
      { id: "a", label: "發通稿炒敬業，買水軍", money: -10000, reputation: 15, result: "「為戲受傷」衝上熱評。你知道那不是設計，觀眾以為是敬業。" },
      { id: "b", label: "賠醫藥費，停工三天", money: -15000, reputation: 5, result: "人先躺平，戲表往後。貴，但是這次沒有人再受傷。" },
      { id: "c", label: "把真實慘叫剪進正片", money: 5000, reputation: -10, result: "那一聲太真了。播放量起得很快，評論區也起得很快。" },
    ],
  },
  {
    id: "smirk",
    title: "歪嘴龍王附體",
    setup: "男二嫌戲份不夠爽，私自改詞。每次出場都歪嘴笑，還自稱隱世戰神。",
    choices: [
      { id: "a", label: "隨便他改，越土越有人看", money: 8000, reputation: -5, result: "歪嘴名場面被截成表情包。你賺到討論，也賺到一點羞恥。" },
      { id: "b", label: "當場斥責，扣通告費", money: 3000, reputation: 10, result: "嘴正回來了。通告費扣得不多，片場的規矩扣得很清楚。" },
      { id: "c", label: "加錢，讓他把嘴歪得更誇張", money: -5000, reputation: 15, result: "你把土味加到上限。觀眾一邊罵一邊模仿，這集的完播意外地高。" },
    ],
  },
  {
    id: "aunt",
    title: "帶資進組的真公主",
    setup: "投資人的七十歲阿姨帶資進組，強行要演十八歲純情白月光，還要跟二十歲男主有吻戲。",
    choices: [
      { id: "a", label: "向資本低頭", money: 50000, reputation: -35, result: "錢多到能再拍兩部。畫面少到你不敢自己回看。" },
      { id: "b", label: "改成母子認親", money: 20000, reputation: 5, result: "吻戲沒了，認親哭戲來了。金主阿姨覺得自己更有戲，觀眾也比較能看。" },
      { id: "c", label: "死也不從，連夜解約", money: -30000, reputation: 30, result: "你帶走了底片和骨頭。帳戶很痛，圈裡這次記得你的名字。" },
    ],
  },
  {
    id: "extras",
    title: "群演集體罷工",
    setup: "原定拍戰神歸來、萬人下跪。群演因為便當沒有雞腿，在宮門口集體坐下不幹。",
    choices: [
      { id: "a", label: "每人加一個雞腿", money: -5000, reputation: 10, result: "雞腿一到，膝蓋也到了。大場面保住，餐車老闆看你的眼神都不一樣。" },
      { id: "b", label: "用五毛特效複製人數", money: -1000, reputation: -10, result: "同一張臉跪了八百遍。眼尖的人已經在數這個人有幾條腿。" },
      { id: "c", label: "改成大家都走光的文藝片", money: 0, reputation: 5, result: "戰神推門，廣場空的。意外地安靜，也意外地有人說這集最不像短劇。" },
    ],
  },
  {
    id: "kick",
    title: "手撕渣男用力過猛",
    setup: "正宮手撕渣男太入戲，一腳把男演員踹進攝影棚旁邊的蓮花池。水花比台詞先到。",
    choices: [
      { id: "a", label: "太精彩了，不准撈，繼續拍", money: 5000, reputation: 15, result: "你讓攝影機跟著水花走。這段後來被截成教材，也變成男演員的心理陰影。" },
      { id: "b", label: "撈人、送醫、賠禮", money: -8000, reputation: 5, result: "人先上岸。蓮花池還在，拍表往後，道歉比劇本長。" },
      { id: "c", label: "買熱搜「正宮的憤怒」", money: -12000, reputation: 20, result: "熱搜比蓮花開得快。女性觀眾站成一排，男主的濕髮變成了正義。" },
    ],
  },
  {
    id: "copy",
    title: "劇本涉嫌嚴重抄襲",
    setup: "上映前夕，編劇承認這部劇是拿五部熱門短劇拼出來的。對家已經在磨刀。",
    choices: [
      { id: "a", label: "給原作者塞封口費", money: -15000, reputation: 0, result: "嘴暫時閉上了。口碑沒加分，帳戶先瘦一圈，你知道這不是辦法。" },
      { id: "b", label: "大方承認，自黑縫合怪", money: -5000, reputation: 10, result: "你先笑自己。有人罵得沒力氣了，有人說至少這部縫合怪肯認。" },
      { id: "c", label: "嘴硬到底，反告對方蹭熱度", money: -10000, reputation: -20, result: "律師函比預告片先出。討論還在，好感先走了。" },
    ],
  },
  {
    id: "tag",
    title: "瘋狂的服化道",
    setup: "霸總的愛馬仕西裝其實是網購包郵款。特寫裡，標籤沒剪，價格還掛在領口。",
    choices: [
      { id: "a", label: "當作沒看到，觀眾在看臉", money: 2000, reputation: -8, result: "標籤留在成片裡。截圖比正片傳得更快。" },
      { id: "b", label: "花錢讓後期把標籤修掉", money: -4000, reputation: 5, result: "領口乾淨了。貴的是那一幀，不是那套西裝。" },
      { id: "c", label: "發聲明說總裁崇尚節儉", money: 0, reputation: 12, result: "你把穿幫收成人設。有人笑，有人居然信了，兩邊都在轉。" },
    ],
  },
  {
    id: "censor",
    title: "短劇審查突襲",
    setup: "扇巴掌、吐血、炫富太密，被點名價值觀扭曲。不上修改，這部就上不了。",
    choices: [
      { id: "a", label: "砸大錢公關，保住上映", money: -40000, reputation: 0, result: "資格保住了。內容幾乎沒動，錢包動得很徹底。" },
      { id: "b", label: "把巴掌改成擊掌慶祝", money: -5000, reputation: -15, result: "仇人突然鼓掌。審查過了，爽感沒了，彈幕問你們在慶祝什麼。" },
      { id: "c", label: "炫富改成路邊攤滷肉飯", money: -2000, reputation: 15, result: "總裁端著滷肉飯談收購。土，但是這次沒人說你在教人拜金。" },
    ],
  },
];

function shuffle<T>(items: T[], rng: () => number): T[] {
  const next = [...items];
  for (let i = next.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [next[i], next[j]] = [next[j], next[i]];
  }
  return next;
}

function snap(value: number, step: number) {
  return Math.round(value / step) * step;
}

function heatFor(traffic: number) {
  if (traffic >= 450000) return "爆款潛力";
  if (traffic >= 280000) return "穩流量";
  return "小成本試水";
}

function pitchFor(hook: string, lead: string, index: number) {
  const lines = [
    `${lead}開場被輕視，三集內用「${hook}」完成第一次公開打臉。`,
    `人設鎖死${lead}，衝突全押在「${hook}」，專吃前 15 秒的完播。`,
    `低臺詞、高反轉：${lead}先忍，再靠${hook}把基礎流量做起來。`,
  ];
  return lines[index % lines.length];
}

export function rollOffers(rng: () => number = Math.random): Offer[] {
  const hooks = shuffle(HOOKS, rng).slice(0, 3);
  const leads = shuffle(LEADS, rng).slice(0, 3);
  const offers = hooks.map((hook, index) => {
    const lead = leads[index];
    const swing = 0.9 + rng() * 0.22;
    const costJitter = -1500 + rng() * 5000;
    const cost = Math.max(8000, snap(hook.cost + lead.cost + costJitter, 500));
    const traffic = Math.max(80000, snap(hook.traffic * lead.traffic * swing, 10000));
    return {
      id: `${LETTERS[index]}-${hook.label}-${lead.label}`,
      letter: LETTERS[index],
      hook: hook.label,
      lead: lead.label,
      pitch: pitchFor(hook.label, lead.label, index),
      cost,
      traffic,
      heat: heatFor(traffic),
    };
  });
  const costs = uniquify(
    offers.map((offer) => offer.cost),
    500,
  );
  const traffic = uniquify(
    offers.map((offer) => offer.traffic),
    10000,
  );
  return offers.map((offer, index) => ({
    ...offer,
    cost: costs[index],
    traffic: traffic[index],
    heat: heatFor(traffic[index]),
  }));
}

function uniquify(values: number[], step: number) {
  const used = new Set<number>();
  return values.map((value) => {
    let next = value;
    while (used.has(next)) next += step;
    used.add(next);
    return next;
  });
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Same three offers on server and first client render, so the board is visible immediately. */
export function openingGame(): GameState {
  return {
    version: 1,
    money: START_MONEY,
    reputation: START_REPUTATION,
    phase: "pick",
    offers: rollOffers(mulberry32(0x51a7c0de)),
    selectedId: null,
    spent: 0,
    incident: null,
    outcome: null,
    resolvedCount: 0,
    seenIds: [],
    release: null,
  };
}

export function freshGame(): GameState {
  return {
    version: 1,
    money: START_MONEY,
    reputation: START_REPUTATION,
    phase: "pick",
    offers: rollOffers(),
    selectedId: null,
    spent: 0,
    incident: null,
    outcome: null,
    resolvedCount: 0,
    seenIds: [],
    release: null,
  };
}

function isChoice(value: unknown): value is Choice {
  if (!value || typeof value !== "object") return false;
  const choice = value as Choice;
  return (
    typeof choice.id === "string" &&
    typeof choice.label === "string" &&
    typeof choice.result === "string" &&
    typeof choice.money === "number" &&
    typeof choice.reputation === "number"
  );
}

function isIncident(value: unknown): value is Incident {
  if (!value || typeof value !== "object") return false;
  const incident = value as Incident;
  return (
    typeof incident.id === "string" &&
    typeof incident.title === "string" &&
    typeof incident.setup === "string" &&
    Array.isArray(incident.choices) &&
    incident.choices.length === 3 &&
    incident.choices.every(isChoice)
  );
}

function isOutcome(value: unknown): value is Outcome {
  if (!value || typeof value !== "object") return false;
  const outcome = value as Outcome;
  return typeof outcome.result === "string" && typeof outcome.title === "string";
}

function isRelease(value: unknown): value is ReleaseResult {
  if (!value || typeof value !== "object") return false;
  const release = value as ReleaseResult;
  return (
    typeof release.views === "number" &&
    typeof release.profit === "number" &&
    typeof release.baseTraffic === "number" &&
    Array.isArray(release.comments)
  );
}

function isOffer(value: unknown): value is Offer {
  if (!value || typeof value !== "object") return false;
  const offer = value as Offer;
  return (
    typeof offer.id === "string" &&
    (offer.letter === "A" || offer.letter === "B" || offer.letter === "C") &&
    typeof offer.hook === "string" &&
    typeof offer.lead === "string" &&
    typeof offer.cost === "number" &&
    typeof offer.traffic === "number"
  );
}

export function loadGame(): GameState | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as GameState;
    if (parsed.version !== 1) return null;
    if (parsed.phase !== "pick" && parsed.phase !== "cast" && parsed.phase !== "release") return null;
    if (!Array.isArray(parsed.offers) || !parsed.offers.every(isOffer)) return null;
    if (typeof parsed.money !== "number" || typeof parsed.reputation !== "number") return null;
    const release = isRelease(parsed.release) ? parsed.release : null;
    return {
      ...parsed,
      phase: parsed.phase === "release" && !release ? "cast" : parsed.phase,
      incident: isIncident(parsed.incident) ? parsed.incident : null,
      outcome: isOutcome(parsed.outcome) ? parsed.outcome : null,
      resolvedCount: typeof parsed.resolvedCount === "number" ? parsed.resolvedCount : 0,
      seenIds: Array.isArray(parsed.seenIds) ? parsed.seenIds.filter((id) => typeof id === "string") : [],
      release,
    };
  } catch {
    return null;
  }
}

export function saveGame(state: GameState) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function selectOffer(state: GameState, id: string): GameState {
  if (state.phase !== "pick") return state;
  const offer = state.offers.find((item) => item.id === id);
  if (!offer || offer.cost > state.money) return state;
  return {
    ...state,
    money: state.money - offer.cost,
    phase: "cast",
    selectedId: offer.id,
    spent: offer.cost,
    incident: null,
    outcome: null,
    resolvedCount: 0,
    seenIds: [],
    release: null,
  };
}

export function startShoot(state: GameState): GameState {
  if (state.phase !== "cast" || state.incident) return state;
  if (state.resolvedCount >= EVENTS_BEFORE_RELEASE) return state;
  const pool = INCIDENTS.filter((item) => !state.seenIds.includes(item.id));
  const source = pool.length > 0 ? pool : INCIDENTS;
  const incident = source[Math.floor(Math.random() * source.length)];
  return { ...state, incident, outcome: null };
}

export function resolveChoice(state: GameState, choiceId: string): GameState {
  const choice = state.incident?.choices.find((item) => item.id === choiceId);
  if (!state.incident || !choice) return state;
  const reputation = Math.min(100, Math.max(0, state.reputation + choice.reputation));
  return {
    ...state,
    money: state.money + choice.money,
    reputation,
    incident: null,
    seenIds: state.seenIds.includes(state.incident.id)
      ? state.seenIds
      : [...state.seenIds, state.incident.id],
    resolvedCount: state.resolvedCount + 1,
    outcome: {
      incidentId: state.incident.id,
      title: state.incident.title,
      choiceLabel: choice.label,
      result: choice.result,
      moneyDelta: choice.money,
      reputationDelta: choice.reputation,
    },
  };
}

const COMMENTS = [
  "這霸總長得像清明節代言人",
  "這巴掌打得好響，我喜歡",
  "太爽了，已充值 100 元",
  "女主這一腳，我隔著螢幕都疼",
  "戰神歸來結果騎腳踏車，我笑出聲",
  "字幕組是不是也在演",
  "這劇的邏輯已往生，但我還在看",
  "已分享到家族群，我媽問什麼是贅婿",
  "男主眼神殺，殺的是我的智商",
  "正片不及花絮狠",
  "這集的財神爺是金主，不是主角",
  "我媽說傷風敗俗，然後自己看到第三集",
  "巴掌聲比對白好聽",
  "已把進度條拖到扇巴掌",
  "這不是短劇，這是情緒回收站",
  "充值的時候手比腦子快",
  "霸總的西裝標籤我截圖了",
  "蓮花池那段我倒回去看了四次",
  "建議把審查意見也剪進正片",
  "朋友說土，我說你不懂什麼叫爽",
  "正宮這集贏了，我的錢包輸了",
  "滷肉飯總裁，我可以",
  "同一張群演臉跪了八百次，我數過",
  "歪嘴一出來我就知道要充值了",
];

function rollComments(rng: () => number = Math.random) {
  return shuffle(COMMENTS, rng).slice(0, 12);
}

export function releaseFilm(state: GameState): GameState {
  if (state.phase !== "cast" || state.incident) return state;
  if (state.resolvedCount < EVENTS_BEFORE_RELEASE) return state;
  const offer = state.offers.find((item) => item.id === state.selectedId);
  const baseTraffic = offer?.traffic ?? 0;
  const views = Math.max(0, Math.round(baseTraffic * (state.reputation / START_REPUTATION) + state.money));
  const profit = Math.round(views * 0.08) - state.spent;
  return {
    ...state,
    phase: "release",
    release: {
      views,
      profit,
      baseTraffic,
      factorLabel: (state.reputation / START_REPUTATION).toFixed(2),
      comments: rollComments(),
    },
  };
}

export function nextSeason(state: GameState): GameState {
  return {
    version: 1,
    money: state.money,
    reputation: state.reputation,
    phase: "pick",
    offers: rollOffers(),
    selectedId: null,
    spent: 0,
    incident: null,
    outcome: null,
    resolvedCount: 0,
    seenIds: [],
    release: null,
  };
}

export function rerollOffers(state: GameState): GameState {
  if (state.phase !== "pick") return state;
  return { ...state, offers: rollOffers() };
}

export function formatNum(value: number) {
  return new Intl.NumberFormat("zh-Hant").format(value);
}

export function formatDelta(value: number) {
  if (value === 0) return "0";
  const sign = value > 0 ? "+" : "−";
  return sign + formatNum(Math.abs(value));
}
