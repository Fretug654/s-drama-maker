//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D3suCF-i.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-ChExANLB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ChExANLB.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-cPkueJUT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
