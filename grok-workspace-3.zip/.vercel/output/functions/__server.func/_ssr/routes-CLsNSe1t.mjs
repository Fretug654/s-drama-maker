import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RefreshCw, i as RotateCcw, o as Clapperboard, r as Star, t as Wallet } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CLsNSe1t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var START_MONEY = 1e5;
var STORAGE_KEY = "duanju-tycoon-v1";
var HOOKS = [
	{
		label: "戰神歸來",
		cost: 28e3,
		traffic: 42e4
	},
	{
		label: "手撕渣男",
		cost: 12e3,
		traffic: 26e4
	},
	{
		label: "重生復仇",
		cost: 22e3,
		traffic: 38e4
	},
	{
		label: "閃婚霸總",
		cost: 26e3,
		traffic: 35e4
	},
	{
		label: "真假千金",
		cost: 18e3,
		traffic: 31e4
	},
	{
		label: "追妻火葬場",
		cost: 2e4,
		traffic: 4e5
	},
	{
		label: "帶球跑",
		cost: 14e3,
		traffic: 24e4
	},
	{
		label: "隱婚馬甲",
		cost: 24e3,
		traffic: 36e4
	},
	{
		label: "穿越宮鬥",
		cost: 36e3,
		traffic: 45e4
	},
	{
		label: "神醫下山",
		cost: 2e4,
		traffic: 28e4
	},
	{
		label: "系統逆襲",
		cost: 16e3,
		traffic: 25e4
	},
	{
		label: "豪門棄婦",
		cost: 15e3,
		traffic: 27e4
	},
	{
		label: "替嫁契約",
		cost: 17e3,
		traffic: 29e4
	},
	{
		label: "鑑寶撿漏",
		cost: 11e3,
		traffic: 18e4
	},
	{
		label: "直播打臉",
		cost: 13e3,
		traffic: 33e4
	},
	{
		label: "先婚後愛",
		cost: 16e3,
		traffic: 3e5
	},
	{
		label: "團寵奶包",
		cost: 19e3,
		traffic: 34e4
	},
	{
		label: "年代逆襲",
		cost: 21e3,
		traffic: 26e4
	}
];
var LEADS = [
	{
		label: "贅婿",
		cost: 8e3,
		traffic: 1.15
	},
	{
		label: "主婦",
		cost: 4e3,
		traffic: .95
	},
	{
		label: "千金",
		cost: 12e3,
		traffic: 1.2
	},
	{
		label: "霸總",
		cost: 14e3,
		traffic: 1.18
	},
	{
		label: "女強人",
		cost: 9e3,
		traffic: 1.1
	},
	{
		label: "龍王",
		cost: 1e4,
		traffic: 1.12
	},
	{
		label: "白月光",
		cost: 7e3,
		traffic: 1.05
	},
	{
		label: "病嬌",
		cost: 6e3,
		traffic: 1.08
	},
	{
		label: "婆媳",
		cost: 3e3,
		traffic: .9
	},
	{
		label: "農村少年",
		cost: 2e3,
		traffic: .85
	},
	{
		label: "王牌律師",
		cost: 11e3,
		traffic: 1.06
	},
	{
		label: "天才醫生",
		cost: 1e4,
		traffic: 1.04
	},
	{
		label: "落魄千金",
		cost: 8e3,
		traffic: 1.1
	},
	{
		label: "隱藏大佬",
		cost: 9e3,
		traffic: 1.14
	},
	{
		label: "單親媽媽",
		cost: 5e3,
		traffic: 1
	}
];
var LETTERS = [
	"A",
	"B",
	"C"
];
var INCIDENTS = [
	{
		id: "tesla",
		title: "金主硬塞廣告",
		setup: "金主配偶要求在古裝劇裡硬塞一輛特斯拉當坐騎，還要主角對著車子發表兩分鐘讚美。",
		choices: [
			{
				id: "a",
				label: "順從金主",
				money: 2e4,
				reputation: -15,
				result: "古裝主角當眾夸車。錢進帳了，彈幕已經在問這是哪個朝代的牌照。"
			},
			{
				id: "b",
				label: "嚴詞拒絕，文人要有骨氣",
				money: -1e4,
				reputation: 20,
				result: "尾款黃了，但組裡有人第一次喊你導演，而不是金主的傳聲筒。"
			},
			{
				id: "c",
				label: "魔改成穿越來的神車",
				money: 5e3,
				reputation: 5,
				result: "你讓霸總說這是未來坐騎。荒謬被收編成設定，居然還有人磕上了。"
			}
		]
	},
	{
		id: "affair",
		title: "主演爆出驚天大瓜",
		setup: "男主角被狗仔爆出同時劈腿四個女網紅，熱搜直接炸開，距離今晚的條還有三小時。",
		choices: [
			{
				id: "a",
				label: "砸錢撤熱搜",
				money: -3e4,
				reputation: -5,
				result: "熱搜下去了，帳單沒有。觀眾只記得你在遮，不記得你在拍什麼。"
			},
			{
				id: "b",
				label: "加一場他被扇巴掌的戲",
				money: -5e3,
				reputation: 25,
				result: "你把瓜寫進正片。巴掌比聲明有用，全網說這才叫因果。"
			},
			{
				id: "c",
				label: "換角，找群演頂替",
				money: -2e4,
				reputation: 10,
				result: "臉換了，戲還在。老粉罵一輪，新觀眾根本沒發現男主曾經有過新聞。"
			}
		]
	},
	{
		id: "pan",
		title: "扇巴掌道具失誤",
		setup: "道具組把軟膠巴掌換成真皮厚平底鍋。女主角一掌下去，男主角輕微腦震盪，叫聲還在錄音裡。",
		choices: [
			{
				id: "a",
				label: "發通稿炒敬業，買水軍",
				money: -1e4,
				reputation: 15,
				result: "「為戲受傷」衝上熱評。你知道那不是設計，觀眾以為是敬業。"
			},
			{
				id: "b",
				label: "賠醫藥費，停工三天",
				money: -15e3,
				reputation: 5,
				result: "人先躺平，戲表往後。貴，但是這次沒有人再受傷。"
			},
			{
				id: "c",
				label: "把真實慘叫剪進正片",
				money: 5e3,
				reputation: -10,
				result: "那一聲太真了。播放量起得很快，評論區也起得很快。"
			}
		]
	},
	{
		id: "smirk",
		title: "歪嘴龍王附體",
		setup: "男二嫌戲份不夠爽，私自改詞。每次出場都歪嘴笑，還自稱隱世戰神。",
		choices: [
			{
				id: "a",
				label: "隨便他改，越土越有人看",
				money: 8e3,
				reputation: -5,
				result: "歪嘴名場面被截成表情包。你賺到討論，也賺到一點羞恥。"
			},
			{
				id: "b",
				label: "當場斥責，扣通告費",
				money: 3e3,
				reputation: 10,
				result: "嘴正回來了。通告費扣得不多，片場的規矩扣得很清楚。"
			},
			{
				id: "c",
				label: "加錢，讓他把嘴歪得更誇張",
				money: -5e3,
				reputation: 15,
				result: "你把土味加到上限。觀眾一邊罵一邊模仿，這集的完播意外地高。"
			}
		]
	},
	{
		id: "aunt",
		title: "帶資進組的真公主",
		setup: "投資人的七十歲阿姨帶資進組，強行要演十八歲純情白月光，還要跟二十歲男主有吻戲。",
		choices: [
			{
				id: "a",
				label: "向資本低頭",
				money: 5e4,
				reputation: -35,
				result: "錢多到能再拍兩部。畫面少到你不敢自己回看。"
			},
			{
				id: "b",
				label: "改成母子認親",
				money: 2e4,
				reputation: 5,
				result: "吻戲沒了，認親哭戲來了。金主阿姨覺得自己更有戲，觀眾也比較能看。"
			},
			{
				id: "c",
				label: "死也不從，連夜解約",
				money: -3e4,
				reputation: 30,
				result: "你帶走了底片和骨頭。帳戶很痛，圈裡這次記得你的名字。"
			}
		]
	},
	{
		id: "extras",
		title: "群演集體罷工",
		setup: "原定拍戰神歸來、萬人下跪。群演因為便當沒有雞腿，在宮門口集體坐下不幹。",
		choices: [
			{
				id: "a",
				label: "每人加一個雞腿",
				money: -5e3,
				reputation: 10,
				result: "雞腿一到，膝蓋也到了。大場面保住，餐車老闆看你的眼神都不一樣。"
			},
			{
				id: "b",
				label: "用五毛特效複製人數",
				money: -1e3,
				reputation: -10,
				result: "同一張臉跪了八百遍。眼尖的人已經在數這個人有幾條腿。"
			},
			{
				id: "c",
				label: "改成大家都走光的文藝片",
				money: 0,
				reputation: 5,
				result: "戰神推門，廣場空的。意外地安靜，也意外地有人說這集最不像短劇。"
			}
		]
	},
	{
		id: "kick",
		title: "手撕渣男用力過猛",
		setup: "正宮手撕渣男太入戲，一腳把男演員踹進攝影棚旁邊的蓮花池。水花比台詞先到。",
		choices: [
			{
				id: "a",
				label: "太精彩了，不准撈，繼續拍",
				money: 5e3,
				reputation: 15,
				result: "你讓攝影機跟著水花走。這段後來被截成教材，也變成男演員的心理陰影。"
			},
			{
				id: "b",
				label: "撈人、送醫、賠禮",
				money: -8e3,
				reputation: 5,
				result: "人先上岸。蓮花池還在，拍表往後，道歉比劇本長。"
			},
			{
				id: "c",
				label: "買熱搜「正宮的憤怒」",
				money: -12e3,
				reputation: 20,
				result: "熱搜比蓮花開得快。女性觀眾站成一排，男主的濕髮變成了正義。"
			}
		]
	},
	{
		id: "copy",
		title: "劇本涉嫌嚴重抄襲",
		setup: "上映前夕，編劇承認這部劇是拿五部熱門短劇拼出來的。對家已經在磨刀。",
		choices: [
			{
				id: "a",
				label: "給原作者塞封口費",
				money: -15e3,
				reputation: 0,
				result: "嘴暫時閉上了。口碑沒加分，帳戶先瘦一圈，你知道這不是辦法。"
			},
			{
				id: "b",
				label: "大方承認，自黑縫合怪",
				money: -5e3,
				reputation: 10,
				result: "你先笑自己。有人罵得沒力氣了，有人說至少這部縫合怪肯認。"
			},
			{
				id: "c",
				label: "嘴硬到底，反告對方蹭熱度",
				money: -1e4,
				reputation: -20,
				result: "律師函比預告片先出。討論還在，好感先走了。"
			}
		]
	},
	{
		id: "tag",
		title: "瘋狂的服化道",
		setup: "霸總的愛馬仕西裝其實是網購包郵款。特寫裡，標籤沒剪，價格還掛在領口。",
		choices: [
			{
				id: "a",
				label: "當作沒看到，觀眾在看臉",
				money: 2e3,
				reputation: -8,
				result: "標籤留在成片裡。截圖比正片傳得更快。"
			},
			{
				id: "b",
				label: "花錢讓後期把標籤修掉",
				money: -4e3,
				reputation: 5,
				result: "領口乾淨了。貴的是那一幀，不是那套西裝。"
			},
			{
				id: "c",
				label: "發聲明說總裁崇尚節儉",
				money: 0,
				reputation: 12,
				result: "你把穿幫收成人設。有人笑，有人居然信了，兩邊都在轉。"
			}
		]
	},
	{
		id: "censor",
		title: "短劇審查突襲",
		setup: "扇巴掌、吐血、炫富太密，被點名價值觀扭曲。不上修改，這部就上不了。",
		choices: [
			{
				id: "a",
				label: "砸大錢公關，保住上映",
				money: -4e4,
				reputation: 0,
				result: "資格保住了。內容幾乎沒動，錢包動得很徹底。"
			},
			{
				id: "b",
				label: "把巴掌改成擊掌慶祝",
				money: -5e3,
				reputation: -15,
				result: "仇人突然鼓掌。審查過了，爽感沒了，彈幕問你們在慶祝什麼。"
			},
			{
				id: "c",
				label: "炫富改成路邊攤滷肉飯",
				money: -2e3,
				reputation: 15,
				result: "總裁端著滷肉飯談收購。土，但是這次沒人說你在教人拜金。"
			}
		]
	}
];
function shuffle(items, rng) {
	const next = [...items];
	for (let i = next.length - 1; i > 0; i -= 1) {
		const j = Math.floor(rng() * (i + 1));
		[next[i], next[j]] = [next[j], next[i]];
	}
	return next;
}
function snap(value, step) {
	return Math.round(value / step) * step;
}
function heatFor(traffic) {
	if (traffic >= 45e4) return "爆款潛力";
	if (traffic >= 28e4) return "穩流量";
	return "小成本試水";
}
function pitchFor(hook, lead, index) {
	const lines = [
		`${lead}開場被輕視，三集內用「${hook}」完成第一次公開打臉。`,
		`人設鎖死${lead}，衝突全押在「${hook}」，專吃前 15 秒的完播。`,
		`低臺詞、高反轉：${lead}先忍，再靠${hook}把基礎流量做起來。`
	];
	return lines[index % lines.length];
}
function rollOffers(rng = Math.random) {
	const hooks = shuffle(HOOKS, rng).slice(0, 3);
	const leads = shuffle(LEADS, rng).slice(0, 3);
	const offers = hooks.map((hook, index) => {
		const lead = leads[index];
		const swing = .9 + rng() * .22;
		const costJitter = -1500 + rng() * 5e3;
		const cost = Math.max(8e3, snap(hook.cost + lead.cost + costJitter, 500));
		const traffic = Math.max(8e4, snap(hook.traffic * lead.traffic * swing, 1e4));
		return {
			id: `${LETTERS[index]}-${hook.label}-${lead.label}`,
			letter: LETTERS[index],
			hook: hook.label,
			lead: lead.label,
			pitch: pitchFor(hook.label, lead.label, index),
			cost,
			traffic,
			heat: heatFor(traffic)
		};
	});
	const costs = uniquify(offers.map((offer) => offer.cost), 500);
	const traffic = uniquify(offers.map((offer) => offer.traffic), 1e4);
	return offers.map((offer, index) => ({
		...offer,
		cost: costs[index],
		traffic: traffic[index],
		heat: heatFor(traffic[index])
	}));
}
function uniquify(values, step) {
	const used = /* @__PURE__ */ new Set();
	return values.map((value) => {
		let next = value;
		while (used.has(next)) next += step;
		used.add(next);
		return next;
	});
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
/** Same three offers on server and first client render, so the board is visible immediately. */
function openingGame() {
	return {
		version: 1,
		money: START_MONEY,
		reputation: 50,
		phase: "pick",
		offers: rollOffers(mulberry32(1369948382)),
		selectedId: null,
		spent: 0,
		incident: null,
		outcome: null,
		resolvedCount: 0,
		seenIds: [],
		release: null
	};
}
function freshGame() {
	return {
		version: 1,
		money: START_MONEY,
		reputation: 50,
		phase: "pick",
		offers: rollOffers(),
		selectedId: null,
		spent: 0,
		incident: null,
		outcome: null,
		resolvedCount: 0,
		seenIds: [],
		release: null
	};
}
function isChoice(value) {
	if (!value || typeof value !== "object") return false;
	const choice = value;
	return typeof choice.id === "string" && typeof choice.label === "string" && typeof choice.result === "string" && typeof choice.money === "number" && typeof choice.reputation === "number";
}
function isIncident(value) {
	if (!value || typeof value !== "object") return false;
	const incident = value;
	return typeof incident.id === "string" && typeof incident.title === "string" && typeof incident.setup === "string" && Array.isArray(incident.choices) && incident.choices.length === 3 && incident.choices.every(isChoice);
}
function isOutcome(value) {
	if (!value || typeof value !== "object") return false;
	const outcome = value;
	return typeof outcome.result === "string" && typeof outcome.title === "string";
}
function isRelease(value) {
	if (!value || typeof value !== "object") return false;
	const release = value;
	return typeof release.views === "number" && typeof release.profit === "number" && typeof release.baseTraffic === "number" && Array.isArray(release.comments);
}
function isOffer(value) {
	if (!value || typeof value !== "object") return false;
	const offer = value;
	return typeof offer.id === "string" && (offer.letter === "A" || offer.letter === "B" || offer.letter === "C") && typeof offer.hook === "string" && typeof offer.lead === "string" && typeof offer.cost === "number" && typeof offer.traffic === "number";
}
function loadGame() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (parsed.version !== 1) return null;
		if (parsed.phase !== "pick" && parsed.phase !== "cast" && parsed.phase !== "release") return null;
		if (!Array.isArray(parsed.offers) || !parsed.offers.every(isOffer)) return null;
		if (typeof parsed.money !== "number" || typeof parsed.reputation !== "number") return null;
		const release = isRelease(parsed.release) ? parsed.release : null;
		return {
			...parsed,
			phase: parsed.phase === "release" && !release ? "cast" : parsed.phase,
			incident: isIncident(parsed.incident) ? parsed.incident : null,
			outcome: isOutcome(parsed.outcome) ? parsed.outcome : null,
			resolvedCount: typeof parsed.resolvedCount === "number" ? parsed.resolvedCount : 0,
			seenIds: Array.isArray(parsed.seenIds) ? parsed.seenIds.filter((id) => typeof id === "string") : [],
			release
		};
	} catch {
		return null;
	}
}
function saveGame(state) {
	if (typeof window === "undefined") return;
	window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}
function selectOffer(state, id) {
	if (state.phase !== "pick") return state;
	const offer = state.offers.find((item) => item.id === id);
	if (!offer || offer.cost > state.money) return state;
	return {
		...state,
		money: state.money - offer.cost,
		phase: "cast",
		selectedId: offer.id,
		spent: offer.cost,
		incident: null,
		outcome: null,
		resolvedCount: 0,
		seenIds: [],
		release: null
	};
}
function startShoot(state) {
	if (state.phase !== "cast" || state.incident) return state;
	if (state.resolvedCount >= 3) return state;
	const pool = INCIDENTS.filter((item) => !state.seenIds.includes(item.id));
	const source = pool.length > 0 ? pool : INCIDENTS;
	const incident = source[Math.floor(Math.random() * source.length)];
	return {
		...state,
		incident,
		outcome: null
	};
}
function resolveChoice(state, choiceId) {
	const choice = state.incident?.choices.find((item) => item.id === choiceId);
	if (!state.incident || !choice) return state;
	const reputation = Math.min(100, Math.max(0, state.reputation + choice.reputation));
	return {
		...state,
		money: state.money + choice.money,
		reputation,
		incident: null,
		seenIds: state.seenIds.includes(state.incident.id) ? state.seenIds : [...state.seenIds, state.incident.id],
		resolvedCount: state.resolvedCount + 1,
		outcome: {
			incidentId: state.incident.id,
			title: state.incident.title,
			choiceLabel: choice.label,
			result: choice.result,
			moneyDelta: choice.money,
			reputationDelta: choice.reputation
		}
	};
}
var COMMENTS = [
	"這霸總長得像清明節代言人",
	"這巴掌打得好響，我喜歡",
	"太爽了，已充值 100 元",
	"女主這一腳，我隔著螢幕都疼",
	"戰神歸來結果騎腳踏車，我笑出聲",
	"字幕組是不是也在演",
	"這劇的邏輯已往生，但我還在看",
	"已分享到家族群，我媽問什麼是贅婿",
	"男主眼神殺，殺的是我的智商",
	"正片不及花絮狠",
	"這集的財神爺是金主，不是主角",
	"我媽說傷風敗俗，然後自己看到第三集",
	"巴掌聲比對白好聽",
	"已把進度條拖到扇巴掌",
	"這不是短劇，這是情緒回收站",
	"充值的時候手比腦子快",
	"霸總的西裝標籤我截圖了",
	"蓮花池那段我倒回去看了四次",
	"建議把審查意見也剪進正片",
	"朋友說土，我說你不懂什麼叫爽",
	"正宮這集贏了，我的錢包輸了",
	"滷肉飯總裁，我可以",
	"同一張群演臉跪了八百次，我數過",
	"歪嘴一出來我就知道要充值了"
];
function rollComments(rng = Math.random) {
	return shuffle(COMMENTS, rng).slice(0, 12);
}
function releaseFilm(state) {
	if (state.phase !== "cast" || state.incident) return state;
	if (state.resolvedCount < 3) return state;
	const baseTraffic = state.offers.find((item) => item.id === state.selectedId)?.traffic ?? 0;
	const views = Math.max(0, Math.round(baseTraffic * (state.reputation / 50) + state.money));
	const profit = Math.round(views * .08) - state.spent;
	return {
		...state,
		phase: "release",
		release: {
			views,
			profit,
			baseTraffic,
			factorLabel: (state.reputation / 50).toFixed(2),
			comments: rollComments()
		}
	};
}
function nextSeason(state) {
	return {
		version: 1,
		money: state.money,
		reputation: state.reputation,
		phase: "pick",
		offers: rollOffers(),
		selectedId: null,
		spent: 0,
		incident: null,
		outcome: null,
		resolvedCount: 0,
		seenIds: [],
		release: null
	};
}
function rerollOffers(state) {
	if (state.phase !== "pick") return state;
	return {
		...state,
		offers: rollOffers()
	};
}
function formatNum(value) {
	return new Intl.NumberFormat("zh-Hant").format(value);
}
function formatDelta(value) {
	if (value === 0) return "0";
	return (value > 0 ? "+" : "−") + formatNum(Math.abs(value));
}
function Home() {
	const [game, setGame] = (0, import_react.useState)(() => openingGame());
	(0, import_react.useEffect)(() => {
		const saved = loadGame();
		if (saved) setGame(saved);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!game.incident) return;
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = previous;
		};
	}, [game.incident]);
	function commit(next) {
		saveGame(next);
		setGame(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBar, {
				money: game.money,
				reputation: game.reputation
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 py-6 pb-16",
				children: game.phase === "pick" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickBoard, {
					offers: game.offers,
					money: game.money,
					onReroll: () => commit(rerollOffers(game)),
					onSelect: (id) => commit(selectOffer(game, id))
				}) : game.phase === "release" && game.release ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseBoard, {
					offer: game.offers.find((item) => item.id === game.selectedId) ?? null,
					money: game.money,
					reputation: game.reputation,
					spent: game.spent,
					release: game.release,
					onNext: () => commit(nextSeason(game))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CastGate, {
					offer: game.offers.find((item) => item.id === game.selectedId) ?? null,
					spent: game.spent,
					money: game.money,
					reputation: game.reputation,
					outcome: game.outcome,
					shooting: game.incident !== null,
					resolvedCount: game.resolvedCount,
					onRestart: () => commit(freshGame()),
					onShoot: () => commit(startShoot(game)),
					onRelease: () => commit(releaseFilm(game))
				})
			}),
			game.incident ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncidentDialog, {
				incident: game.incident,
				onChoose: (choiceId) => commit(resolveChoice(game, choiceId))
			}) : null
		]
	});
}
function StatusBar({ money, reputation }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-20 border-b border-line bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl items-center gap-3 px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-10 shrink-0 items-center justify-center rounded-xl bg-surface text-gold",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, {
					"aria-hidden": "true",
					className: "size-5"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "導演兼製片"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "truncate font-display text-xl text-balance",
					children: "短劇製作大亨"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-5xl grid-cols-2 border-t border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
					"aria-hidden": "true",
					className: "mt-0.5 size-4 shrink-0 text-gold"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "資金"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold tabular-nums",
					children: [formatNum(money), " 元"]
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3 border-l border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
					"aria-hidden": "true",
					className: "mt-0.5 size-4 shrink-0 text-gold"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "公司口碑"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold tabular-nums",
							children: reputation
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-1.5 overflow-hidden rounded-full bg-surface-2",
							role: "meter",
							"aria-label": "公司口碑",
							"aria-valuemin": 0,
							"aria-valuemax": 100,
							"aria-valuenow": reputation,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-gold",
								style: { width: `${reputation}%` }
							})
						})
					]
				})]
			})]
		})]
	});
}
function PickBoard({ offers, money, onReroll, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-gold",
						children: "第一階段 · 劇本挑選"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-2xl text-balance",
						children: "本週可開拍的三組組合"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty text-muted",
						children: "每組都是題材加人物。選定後會立刻扣除製作費，並進入選角。"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onReroll,
				className: "inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 font-medium transition-transform duration-150 ease-out active:scale-[0.96]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
					"aria-hidden": "true",
					className: "size-4"
				}), "換一批"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 gap-4 md:grid-cols-3",
			children: offers.map((offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptCard, {
				offer,
				money,
				onSelect: () => onSelect(offer.id)
			}, offer.id))
		})]
	});
}
function ScriptCard({ offer, money, onSelect }) {
	const affordable = offer.cost <= money;
	const remain = money - offer.cost;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col rounded-2xl bg-paper p-5 text-paper-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-lg",
					children: ["方案 ", offer.letter]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-paper-muted",
					children: offer.heat
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 font-display text-3xl text-balance",
				children: offer.hook
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-paper-muted",
				children: ["× ", offer.lead]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-pretty text-sm leading-relaxed text-paper-muted",
				children: offer.pitch
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid grid-cols-2 gap-3 border-t border-paper-soft pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-sm text-paper-muted",
					children: "成本"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
					className: "mt-1 font-semibold tabular-nums",
					children: [formatNum(offer.cost), " 元"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-sm text-paper-muted",
					children: "預估基礎流量"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-1 font-semibold tabular-nums",
					children: formatNum(offer.traffic)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-paper-muted",
				children: affordable ? `開拍後餘額 ${formatNum(remain)} 元` : `還差 ${formatNum(offer.cost - money)} 元`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onSelect,
				disabled: !affordable,
				className: "mt-4 inline-flex h-12 items-center justify-center rounded-xl bg-gold font-semibold text-gold-ink transition-transform duration-150 ease-out active:scale-[0.96] disabled:bg-paper-soft disabled:text-paper-muted",
				children: affordable ? "選定此劇本" : "資金不足"
			})
		]
	});
}
function CastGate({ offer, spent, money, reputation, outcome, shooting, resolvedCount, onRestart, onShoot, onRelease }) {
	const ready = resolvedCount >= 3;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid grid-cols-1 items-start gap-6 md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-gold",
					children: "第二階段 · 開拍"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl text-balance",
					children: ready ? "三個突發都處理完了" : "劇本已選定，可以開始拍攝"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-pretty text-muted",
					children: ready ? "片場撐過三關。按下殺青，全網會用播放量和利潤告訴你這部劇值不值。" : `連拍 3 個突發才能殺青。現在是第 ${resolvedCount + 1} 關。`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: ready ? onRelease : onShoot,
						disabled: shooting,
						className: "inline-flex h-12 items-center justify-center rounded-xl bg-gold px-4 font-semibold text-gold-ink transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50",
						children: ready ? "電影殺青，全網上映！" : resolvedCount > 0 ? "繼續拍攝" : "開始拍攝"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onRestart,
						className: "inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 font-medium transition-transform duration-150 ease-out active:scale-[0.96]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							"aria-hidden": "true",
							className: "size-4"
						}), "重新開季"]
					})]
				}),
				outcome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutcomeNote, { outcome }) : null
			]
		}), offer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl bg-paper p-5 text-paper-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-paper-muted",
					children: ["已鎖定 · 方案 ", offer.letter]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "mt-2 font-display text-3xl text-balance",
					children: [offer.hook, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-lg text-paper-muted",
						children: ["× ", offer.lead]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-5 grid grid-cols-2 gap-3 border-t border-paper-soft pt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-paper-muted",
							children: "已扣製作費"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "mt-1 font-semibold tabular-nums",
							children: [formatNum(spent), " 元"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-paper-muted",
							children: "預估基礎流量"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-semibold tabular-nums",
							children: formatNum(offer.traffic)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-paper-muted",
							children: "剩餘資金"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "mt-1 font-semibold tabular-nums",
							children: [formatNum(money), " 元"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-paper-muted",
							children: "口碑"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-semibold tabular-nums",
							children: reputation
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-paper-muted",
					children: [
						"突發進度 ",
						Math.min(resolvedCount, 3),
						" / ",
						3
					]
				})
			]
		}) : null]
	});
}
function ReleaseBoard({ offer, money, reputation, spent, release, onNext }) {
	const loop = [...release.comments, ...release.comments];
	const profitLabel = release.profit >= 0 ? "本劇總利潤" : "本劇虧損";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid grid-cols-1 items-start gap-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-gold",
					children: "第三階段 · 上映"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl text-balance",
					children: "電影殺青，全網上映"
				}),
				offer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-pretty text-muted",
					children: [
						offer.hook,
						" × ",
						offer.lead,
						" 已經推上全網。播放量吃的是基礎流量、拍完剩的口碑，還有你口袋裡的資金。"
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl bg-paper p-4 text-paper-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-paper-muted",
							children: "全網最終播放量"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-3xl tabular-nums",
							children: formatNum(release.views)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl bg-paper p-4 text-paper-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-paper-muted",
							children: profitLabel
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 font-display text-3xl tabular-nums",
							children: [formatNum(release.profit), " 元"]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-surface p-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [
							"播放量 = 基礎流量 ",
							formatNum(release.baseTraffic),
							" × 口碑係數 ",
							release.factorLabel,
							"（口碑 ",
							reputation,
							" ÷ 50）+ 剩餘資金 ",
							formatNum(money)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							"總利潤 = 播放量 × 0.08 − 劇本製作費 ",
							formatNum(spent),
							" 元"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onNext,
					className: "inline-flex h-12 items-center justify-center self-start rounded-xl bg-gold px-4 font-semibold text-gold-ink transition-transform duration-150 ease-out active:scale-[0.96]",
					children: "開啟下一賽季"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "flex h-96 flex-col overflow-hidden rounded-2xl border border-line bg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "shrink-0 border-b border-line px-4 py-3 text-sm text-gold",
				children: "彈幕 · 網友毒舌評論"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "comment-reel",
					children: loop.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "border-b border-line px-4 py-3 text-sm",
						children: line
					}, `${line}-${index}`))
				})
			})]
		})]
	});
}
function OutcomeNote({ outcome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-gold",
				children: outcome.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-medium",
				children: outcome.choiceLabel
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-sm text-muted",
				children: outcome.result
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm tabular-nums text-fg",
				children: [
					"資金 ",
					formatDelta(outcome.moneyDelta),
					" 元 · 口碑 ",
					formatDelta(outcome.reputationDelta)
				]
			})
		]
	});
}
function IncidentDialog({ incident, onChoose }) {
	if (!incident) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-30 flex items-end justify-center bg-bg/80 p-4 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "incident-title",
			className: "w-full max-w-lg max-h-screen overflow-y-auto rounded-2xl bg-paper p-5 text-paper-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-paper-muted",
					children: "拍攝突發事件"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "incident-title",
					className: "mt-1 font-display text-2xl text-balance",
					children: incident.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-pretty text-sm leading-relaxed text-paper-muted",
					children: incident.setup
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex flex-col gap-3",
					children: incident.choices.map((choice) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onChoose(choice.id),
						className: "rounded-xl border border-paper-soft bg-paper-soft px-4 py-3 text-left transition-transform duration-150 ease-out active:scale-[0.96]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: choice.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block text-sm tabular-nums text-paper-muted",
							children: [
								"資金 ",
								formatDelta(choice.money),
								" 元 · 口碑 ",
								formatDelta(choice.reputation)
							]
						})]
					}, choice.id))
				})
			]
		})
	});
}
//#endregion
export { Home as component };
